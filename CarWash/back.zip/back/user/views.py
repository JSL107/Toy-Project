from django.shortcuts import render
from rest_framework.decorators import api_view
from .models import User, UserAuth, UserGrade, UserPoint
from .UserSerializer import UserSerializer
from rest_framework.response import Response


# Create your views here.

@api_view(['POST'])
def user_api(request):
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        try:
            serializer.save()
            return Response(serializer.data, status=201)
        except Exception as e:
            return Response({"error_message": str(e)}, status=400)
    return Response(serializer.errors, status=400)
